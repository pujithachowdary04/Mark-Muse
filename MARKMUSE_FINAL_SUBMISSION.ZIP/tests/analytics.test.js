const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

async function loadAnalytics() {
  const source = fs.readFileSync(path.join(__dirname, "../public/js/analytics.js"), "utf8");
  return import(`data:text/javascript;base64,${Buffer.from(source).toString("base64")}`);
}

test("analytics counts words, headings and reading time", async () => {
  const { analyseMarkdown } = await loadAnalytics();
  const result = analyseMarkdown("# Title\n\nOne two three four five.");
  assert.equal(result.words, 7);
  assert.equal(result.headings, 1);
  assert.equal(result.minutes, 1);
  assert.equal(result.paragraphs, 2);
});

test("analytics handles empty documents", async () => {
  const { analyseMarkdown } = await loadAnalytics();
  const result = analyseMarkdown("");
  assert.equal(result.words, 0);
  assert.equal(result.minutes, 0);
  assert.equal(result.readability, "—");
});
