const test = require("node:test");
const assert = require("node:assert/strict");
const request = require("supertest");
const { createApp } = require("../src/app");
const app = createApp();

test("health endpoint responds with service status", async () => {
  const response = await request(app).get("/api/health").expect(200);
  assert.equal(response.body.status, "ok");
});

test("document API creates, reads, updates and deletes a document", async () => {
  const created = await request(app).post("/api/documents")
    .send({ title: "Test document", content: "# Hello" }).expect(201);
  const id = created.body.document.id;
  assert.ok(id);

  const fetched = await request(app).get(`/api/documents/${id}`).expect(200);
  assert.equal(fetched.body.document.title, "Test document");

  await request(app).put(`/api/documents/${id}`)
    .send({ title: "Updated", content: "Updated content" }).expect(200);

  const versions = await request(app).get(`/api/documents/${id}/versions`).expect(200);
  assert.equal(versions.body.versions.length, 2);

  await request(app).delete(`/api/documents/${id}`).expect(204);
  await request(app).get(`/api/documents/${id}`).expect(404);
});

test("document API rejects invalid data", async () => {
  const response = await request(app).post("/api/documents")
    .send({ title: "", content: "x", extra: true }).expect(400);
  assert.equal(response.body.error, "Invalid document data");
});

test("PDF endpoint returns a server-generated PDF", async () => {
  const response = await request(app).post("/api/documents/compile/pdf")
    .send({ title: "PDF test", content: "# PDF heading\n\nPDF body." }).expect(200);
  assert.match(response.headers["content-type"], /application\/pdf/);
  assert.ok(response.body.length > 100);
});

test("API responses include a request correlation ID", async () => {
  const response = await request(app).get("/api/health").expect(200);
  assert.match(response.headers["x-request-id"], /^[0-9a-f-]{36}$/i);
});

test("document API rejects content above the configured schema limit", async () => {
  await request(app).post("/api/documents")
    .send({ title: "Too large", content: "x".repeat(500001) })
    .expect(400);
});

test("document revisions preserve the saved content", async () => {
  const created = await request(app).post("/api/documents")
    .send({ title: "Revision check", content: "# First version" }).expect(201);
  const id = created.body.document.id;
  await request(app).put(`/api/documents/${id}`)
    .send({ title: "Revision check", content: "# Second version" }).expect(200);
  const versions = await request(app).get(`/api/documents/${id}/versions`).expect(200);
  assert.equal(versions.body.versions.length, 2);
  assert.equal(versions.body.versions[0].content, "# Second version");
  assert.equal(versions.body.versions[1].content, "# First version");
  await request(app).delete(`/api/documents/${id}`).expect(204);
});
