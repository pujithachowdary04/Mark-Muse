export function renderMarkdown(source) {
  try {
    const html = window.marked
      ? window.marked.parse(source, { breaks: true, gfm: true })
      : `<pre>${escapeHtml(source)}</pre>`;
    return window.DOMPurify ? window.DOMPurify.sanitize(html) : `<pre>${escapeHtml(source)}</pre>`;
  } catch {
    return `<pre>${escapeHtml(source)}</pre>`;
  }
}
export function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}
export function safeFilename(value, extension) {
  const base = String(value).replace(/[\\/:*?"<>|]+/g, "").trim().replace(/\s+/g, "-").slice(0, 70);
  return `${base || "document"}${extension}`;
}

let mermaidReady = false;
let mermaidCounter = 0;
export async function renderDiagrams(container) {
  const blocks = container.querySelectorAll("pre > code.language-mermaid");
  if (!blocks.length) return;
  if (!window.mermaid) {
    blocks.forEach(code => {
      const note = document.createElement("small");
      note.className = "diagram-note";
      note.textContent = "Diagram library unavailable (offline) — showing source.";
      code.parentElement.after(note);
    });
    return;
  }
  if (!mermaidReady) {
    window.mermaid.initialize({
      startOnLoad: false,
      securityLevel: "strict",
      theme: document.body.classList.contains("dark") ? "dark" : "default"
    });
    mermaidReady = true;
  }
  for (const code of blocks) {
    const pre = code.parentElement;
    const source = code.textContent;
    try {
      const { svg } = await window.mermaid.render(`mm-diagram-${++mermaidCounter}`, source);
      const holder = document.createElement("div");
      holder.className = "mermaid";
      holder.innerHTML = svg;
      pre.replaceWith(holder);
    } catch (error) {
      document.getElementById(`dmm-diagram-${mermaidCounter}`)?.remove();
      const msg = document.createElement("small");
      msg.className = "diagram-error";
      msg.textContent = "Diagram syntax error — check your Mermaid block.";
      pre.after(msg);
    }
  }
}
