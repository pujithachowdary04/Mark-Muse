import { getDocuments, saveDocument, deleteDocument, getVersions, compilePdf } from "./api.js";
import { analyseMarkdown } from "./analytics.js";
import { renderMarkdown, renderDiagrams, safeFilename, escapeHtml } from "./markdown.js";

const $ = id => document.getElementById(id);
const input = $("markdownInput");
const title = $("docTitle");
let activeId = null;
let documents = [];
let saveTimer;
let toastTimer;

const templates = {
  readme: `# Project Name\n\nA short description of this project.\n\n## Features\n- Feature one\n- Feature two\n\n## Installation\n\`\`\`bash\nnpm install\n\`\`\`\n\n## Usage\nExplain how to use the project.\n\n## Tech stack\n- HTML\n- CSS\n- JavaScript\n\n## License\nAdd license details.`,
  api: `# REST API Specification\n\n## Base URL\n\`https://api.example.com/v1\`\n\n## Authentication\nDescribe authentication.\n\n## Endpoints\n### GET /items\nReturns a list of items.\n\n### POST /items\nCreates an item.\n\n## Error handling\nDocument response codes.`,
  changelog: `# Changelog\n\n## [1.0.0] - YYYY-MM-DD\n### Added\n- Initial release.\n\n### Changed\n- Improvements.\n\n### Fixed\n- Bug fixes.\n\n## [Unreleased]\n- Planned work.`,
  rfc: `# Architecture RFC: Title\n\n**Status:** Draft\n\n## 1. Summary\nDescribe the proposal.\n\n## 2. Motivation\nExplain the problem.\n\n## 3. Proposed design\nDescribe the architecture.\n\n## 4. Alternatives\nList trade-offs.\n\n## 5. Risks\nIdentify mitigations.\n\n## 6. Decision\nRecord the decision.\n\n## Architecture diagram\n\`\`\`mermaid\nflowchart TD\n  A[User] --> B[MarkMuse Editor]\n  B --> C[Preview]\n  B --> D[Express API]\n  D --> E[(SQLite)]\n\`\`\``
};

function toast(message) {
  $("toast").textContent = message;
  $("toast").classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => $("toast").classList.remove("show"), 2800);
}
function status(message) { $("saveStatus").textContent = `● ${message}`; }
function getTitle() { return title.value.trim() || "Untitled Document"; }
function current() { return { id: activeId, title: getTitle(), content: input.value }; }

function updateStats() {
  const data = analyseMarkdown(input.value);
  $("wordCount").textContent = data.words.toLocaleString();
  $("charCount").textContent = data.characters.toLocaleString();
  $("readTime").textContent = `${data.minutes} min`;
  $("headingCount").textContent = data.headings;
  $("readability").textContent = data.readability;
  $("progressBar").style.width = `${data.completion}%`;
  $("insights").textContent = `${data.paragraphs} paragraph(s), ${data.headings} heading(s), and approximately ${data.minutes} minute(s) of reading.`;
}
function updateCursor() {
  const before = input.value.slice(0, input.selectionStart);
  const lines = before.split("\n");
  $("cursorStatus").textContent = `Line ${lines.length}, Column ${lines.at(-1).length + 1}`;
}
let diagramTimer;
function updatePreview() {
  $("preview").innerHTML = renderMarkdown(input.value);
  clearTimeout(diagramTimer);
  diagramTimer = setTimeout(() => renderDiagrams($("preview")), 250);
  updateStats();
  updateCursor();
}
function renderDocuments() {
  $("docTotal").textContent = documents.length;
  const list = $("documentList");
  list.replaceChildren();
  if (!documents.length) {
    const empty = document.createElement("p");
    empty.className = "muted";
    empty.textContent = "No saved documents yet.";
    list.append(empty);
    return;
  }
  for (const doc of documents) {
    const row = document.createElement("div");
    row.className = `doc-row${doc.id === activeId ? " selected" : ""}`;
    const open = document.createElement("button");
    open.className = "doc-open";
    open.textContent = doc.title;
    open.title = doc.title;
    open.addEventListener("click", () => openDocument(doc.id));
    const remove = document.createElement("button");
    remove.className = "doc-delete";
    remove.textContent = "×";
    remove.setAttribute("aria-label", `Delete ${doc.title}`);
    remove.addEventListener("click", () => removeDocument(doc.id));
    row.append(open, remove);
    list.append(row);
  }
}
async function refreshDocuments() {
  documents = await getDocuments();
  renderDocuments();
}
async function openDocument(id) {
  try {
    const doc = documents.find(item => item.id === id);
    if (!doc) return;
    activeId = doc.id;
    title.value = doc.title;
    input.value = doc.content;
    updatePreview();
    renderDocuments();
    status("Document loaded");
    await refreshVersions();
  } catch (error) { toast(error.message); }
}
async function save(silent = false) {
  try {
    status("Saving…");
    const saved = await saveDocument(current());
    activeId = saved.id;
    await refreshDocuments();
    status("Saved to database");
    if (!silent) toast("Document saved to the MarkMuse database.");
  } catch (error) {
    status("Save failed");
    toast(error.message);
  }
}
async function removeDocument(id) {
  if (!confirm("Delete this document and its revision history?")) return;
  try {
    await deleteDocument(id);
    if (activeId === id) newDocument();
    await refreshDocuments();
    toast("Document deleted.");
  } catch (error) { toast(error.message); }
}
function newDocument() {
  activeId = null;
  title.value = "Untitled Document";
  input.value = "";
  updatePreview();
  renderDocuments();
  $("versionInfo").textContent = "Save a document to create its first revision.";
  $("versionList").replaceChildren();
  status("New document");
  input.focus();
}
function scheduleAutosave() {
  status("Unsaved changes");
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    if (input.value.trim() || title.value.trim() !== "Untitled Document") save(true);
  }, 1200);
}
async function refreshVersions() {
  if (!activeId) return;
  try {
    const versions = await getVersions(activeId);
    $("versionInfo").textContent = `${versions.length} saved revision(s).`;
    const list = $("versionList");
    list.replaceChildren();
    versions.slice(0, 3).forEach(version => {
      const line = document.createElement("small");
      line.textContent = new Date(version.createdAt).toLocaleString();
      list.append(line);
    });
    $("revisionItems").replaceChildren();
    versions.forEach((version, index) => {
      const item = document.createElement("article");
      item.className = "revision";
      const heading = document.createElement("b");
      heading.textContent = `Revision ${versions.length - index}`;
      const date = document.createElement("small");
      date.textContent = new Date(version.createdAt).toLocaleString();
      const restore = document.createElement("button");
      restore.className = "outline small";
      restore.textContent = "Restore";
      restore.addEventListener("click", () => {
        title.value = version.title;
        input.value = version.content;
        updatePreview();
        $("versionsDialog").close();
        scheduleAutosave();
      });
      item.append(heading, date, restore);
      $("revisionItems").append(item);
    });
  } catch (error) { toast(error.message); }
}
function downloadBlob(blob, name) {
  if (!(blob instanceof Blob) || blob.size === 0) throw new Error("The generated file is empty or invalid.");
  const url = URL.createObjectURL(blob);
  try {
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = name;
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
  } finally {
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }
}
async function makePdf() {
  const button = $("pdfBtn");
  button.disabled = true;
  button.textContent = "Compiling…";
  try {
    const blob = await compilePdf(getTitle(), input.value);
    downloadBlob(blob, safeFilename(getTitle(), ".pdf"));
    toast("PDF compiled by the server successfully.");
  } catch (error) {
    toast(error.message);
  } finally {
    button.disabled = false;
    button.textContent = "Compile PDF ↓";
  }
}
function exportHtml() {
  const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>${escapeHtml(getTitle())}</title><style>body{max-width:850px;margin:50px auto;padding:0 24px;font:16px/1.7 Arial;color:#242333}pre{background:#f2f0fa;padding:16px;overflow:auto}blockquote{border-left:3px solid #6558d9;padding-left:15px;color:#666}table{border-collapse:collapse}td,th{border:1px solid #ddd;padding:8px}</style></head><body><h1>${escapeHtml(getTitle())}</h1>${renderMarkdown(input.value)}</body></html>`;
  downloadBlob(new Blob([html], { type: "text/html;charset=utf-8" }), safeFilename(getTitle(), ".html"));
}
function insertText(value) {
  input.setRangeText(value, input.selectionStart, input.selectionEnd, "end");
  input.focus();
  updatePreview();
  scheduleAutosave();
}

$("newDoc").addEventListener("click", newDocument);
$("saveBtn").addEventListener("click", () => save());
$("pdfBtn").addEventListener("click", makePdf);
$("exportHtml").addEventListener("click", () => {
  try { exportHtml(); } catch (error) { toast(error.message); }
});
$("savedBtn").addEventListener("click", () => $("documentList").scrollIntoView({ behavior: "smooth" }));
$("templatesBtn").addEventListener("click", () => $("templatesDialog").showModal());
$("versionsBtn").addEventListener("click", async () => {
  if (!activeId) return toast("Save a document first to view its revisions.");
  await refreshVersions();
  $("versionsDialog").showModal();
});
document.querySelectorAll("[data-template]").forEach(button => button.addEventListener("click", () => {
  const key = button.dataset.template;
  input.value = templates[key];
  title.value = ({ readme: "Project README", api: "REST API Specification", changelog: "Changelog", rfc: "Architecture RFC" })[key];
  activeId = null;
  $("templatesDialog").close();
  updatePreview();
  scheduleAutosave();
}));
document.querySelectorAll("[data-insert]").forEach(button => button.addEventListener("click", () => insertText(button.dataset.insert)));
input.addEventListener("input", () => { updatePreview(); scheduleAutosave(); });
input.addEventListener("click", updateCursor);
input.addEventListener("keyup", updateCursor);
title.addEventListener("input", scheduleAutosave);
$("fileInput").addEventListener("change", async event => {
  const file = event.target.files?.[0];
  if (!file) return;
  try {
    const extensionOk = /\.(md|markdown|txt)$/i.test(file.name);
    const mimeOk = ["text/plain", "text/markdown", "application/octet-stream", ""].includes(file.type);
    if (!extensionOk || !mimeOk) throw new Error("Choose a Markdown or plain-text file (.md, .markdown, .txt).");
    if (file.size > 500000) throw new Error("File is too large. Maximum import size is 500 KB.");
    const content = await file.text();
    if (content.includes("\0")) throw new Error("The selected file does not appear to be a text document.");
    title.value = file.name.replace(/\.(md|markdown|txt)$/i, "").slice(0, 100) || "Imported document";
    input.value = content;
    activeId = null;
    updatePreview();
    scheduleAutosave();
    toast("File imported. It will be saved automatically.");
  } catch (error) { toast(error.message || "Unable to import this file."); }
  finally { event.target.value = ""; }
});
$("themeBtn").addEventListener("click", () => {
  document.body.classList.toggle("dark");
  if (window.mermaid) window.mermaid.initialize({ startOnLoad: false, securityLevel: "strict", theme: document.body.classList.contains("dark") ? "dark" : "default" });
  updatePreview();
  localStorage.setItem("markmuse.theme", document.body.classList.contains("dark") ? "dark" : "light");
});
document.addEventListener("keydown", event => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
    event.preventDefault();
    clearTimeout(saveTimer);
    save();
  }
  if (event.key === "Escape") document.querySelectorAll("dialog[open]").forEach(dialog => dialog.close());
});

try {
  if (localStorage.getItem("markmuse.theme") === "dark") document.body.classList.add("dark");
  await refreshDocuments();
  updatePreview();
  status("Connected to database");
} catch (error) {
  status("Server unavailable");
  toast(error.message);
}
