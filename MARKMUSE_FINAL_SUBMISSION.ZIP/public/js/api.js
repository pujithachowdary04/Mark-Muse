const BASE = "/api/documents";

async function request(url, options = {}) {
  let response;
  try {
    response = await fetch(url, {
      ...options,
      headers: { ...(options.body ? { "Content-Type": "application/json" } : {}), ...options.headers }
    });
  } catch {
    throw new Error("Cannot reach the MarkMuse server. Check that the backend is running.");
  }
  if (!response.ok) {
    let detail = {};
    try { detail = await response.json(); } catch {}
    if (Array.isArray(detail.details) && detail.details.length) {
      const messages = detail.details.map(item => `${item.field || "Input"}: ${item.message}`).join("; ");
      throw new Error(`${detail.error || "Validation failed"} — ${messages}`);
    }
    if (response.status === 429) throw new Error("Too many requests. Please wait a moment and try again.");
    if (response.status === 413) throw new Error("The request is too large. Reduce the document size and retry.");
    throw new Error(detail.error || `Request failed (${response.status})`);
  }
  return response.status === 204 ? null : response;
}

export async function getDocuments() {
  return (await (await request(BASE)).json()).documents;
}
export async function getDocument(id) {
  return (await (await request(`${BASE}/${encodeURIComponent(id)}`)).json()).document;
}
export async function saveDocument(doc) {
  const isUpdate = Boolean(doc.id);
  const response = await request(isUpdate ? `${BASE}/${encodeURIComponent(doc.id)}` : BASE, {
    method: isUpdate ? "PUT" : "POST",
    body: JSON.stringify({ title: doc.title, content: doc.content })
  });
  return (await response.json()).document;
}
export async function deleteDocument(id) {
  await request(`${BASE}/${encodeURIComponent(id)}`, { method: "DELETE" });
}
export async function getVersions(id) {
  return (await (await request(`${BASE}/${encodeURIComponent(id)}/versions`)).json()).versions;
}
export async function compilePdf(title, content) {
  const response = await request(`${BASE}/compile/pdf`, {
    method: "POST",
    body: JSON.stringify({ title, content })
  });
  const blob = await response.blob();
  if (!blob.size || blob.type !== "application/pdf") throw new Error("The server returned an invalid PDF file.");
  return blob;
}
