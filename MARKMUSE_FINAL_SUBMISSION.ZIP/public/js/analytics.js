export function analyseMarkdown(source) {
  const words = source.trim() ? source.trim().split(/\s+/u).length : 0;
  const characters = source.length;
  const headings = (source.match(/^#{1,6}\s+.+$/gm) || []).length;
  const paragraphs = source.split(/\n\s*\n/).filter(part => part.trim()).length;
  const sentences = Math.max(1, (source.match(/[.!?]+(?=\s|$)/g) || []).length);
  const averageWords = words / sentences;
  const readability = words === 0 ? "—" : averageWords < 14 ? "Easy" : averageWords < 22 ? "Moderate" : "Dense";
  return {
    words, characters, headings, paragraphs, readability,
    minutes: words ? Math.max(1, Math.ceil(words / 200)) : 0,
    completion: Math.min(100, Math.round(words / 5))
  };
}
