# Quality, Security and Demo Checklist

## Added in this upgrade

- Mermaid diagrams render from fenced `mermaid` blocks using Mermaid strict security mode.
- Pino emits structured JSON logs with request IDs, HTTP method, path, status and duration.
- `X-Request-ID` is returned for support/debug correlation.
- Helmet security headers include a Content Security Policy for the pinned CDN assets.
- API validation errors can show field-level feedback in the browser.
- Integration tests cover request IDs, oversized document validation and revision content integrity.

## Manual demo checklist

1. Start with `npm install` and `npm start`.
2. Open the Architecture RFC template and confirm the Mermaid flowchart renders.
3. Add a fenced Mermaid block and verify the preview updates.
4. Create a document, edit it, save it, and inspect the revision history.
5. Restore an earlier revision and verify the editor content changes.
6. Export Markdown/HTML and compile a server-generated PDF.
7. Toggle dark mode and test the editor at desktop and mobile widths.
8. Run `npm test` and retain the terminal output as evidence.

## Security and scope notes

- Markdown HTML is sanitized with DOMPurify before display.
- Mermaid runs with `securityLevel: "strict"`.
- The API validates title/content shape and size, applies rate limiting, and uses Helmet headers.
- SQLite foreign keys and transactional revision writes preserve document/revision consistency.
- This project does not include authentication or multi-user authorization. Describe it as a single-workspace prototype, not a production multi-user service.
- Mermaid, Marked and DOMPurify are loaded from pinned CDN versions. Offline use requires vendoring audited library files locally.
