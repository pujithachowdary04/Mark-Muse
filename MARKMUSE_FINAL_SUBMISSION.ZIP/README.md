# MarkMuse DocuDash 2.0

A full-stack Markdown documentation editor upgraded from the original client-side prototype.

## Features

- Live Markdown editor and sanitized preview (Marked + DOMPurify)
- Mermaid flowchart and sequence-diagram rendering in the preview (strict security mode)
- GitHub Flavored Markdown parsing, including task-list syntax
- Document create, read, update and delete through REST API
- SQLite persistence instead of browser LocalStorage as the primary database
- Server-side PDF compilation at `POST /api/documents/compile/pdf`
- Markdown and HTML export
- Autosave, templates, import validation and keyboard shortcut (`Ctrl/Cmd + S`)
- Document version history and restore
- Word, character, heading, reading-time and readability analytics
- Dark mode and responsive layout
- Automated unit and API integration tests, including request correlation and revision integrity
- Structured JSON application/request logging with Pino and request IDs
- Security headers, API rate limiting, bounded request payloads and field-level validation feedback

## Architecture

1. **Presentation tier:** `public/` — HTML, CSS and modular browser JavaScript.
2. **Application tier:** `src/app.js`, routes, validation middleware and services — Express REST API.
3. **Data tier:** `src/db.js` — SQLite documents and document revision tables.

## Requirements

- Node.js 20 or newer
- npm

## Run locally

```bash
npm install
npm start
```

Open http://localhost:3000

For development with automatic server restart:

```bash
npm run dev
```

## Run tests

```bash
npm test
```

Tests cover analytics, API health, CRUD operations, invalid and oversized payloads, request correlation, version content integrity and the server-side PDF endpoint.

## API summary

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Health check |
| GET | `/api/documents` | List documents |
| POST | `/api/documents` | Create document |
| GET | `/api/documents/:id` | Read document |
| PUT | `/api/documents/:id` | Update document |
| DELETE | `/api/documents/:id` | Delete document |
| GET | `/api/documents/:id/versions` | Revision history |
| POST | `/api/documents/compile/pdf` | Compile and return PDF |

The PDF endpoint uses PDFKit on the server. It does not open the browser print dialog.

## Notes and limitations

- The project is a local development prototype. It does not implement user accounts or multi-user authorization.
- The PDF renderer supports common Markdown structures (headings, paragraphs, lists, code, blockquotes, rules and tables). Complex embedded HTML, images and advanced styling are not fully reproduced.
- The browser uses pinned CDN-hosted Marked, DOMPurify and Mermaid libraries; an internet connection is needed for these libraries. For an offline deployment, download and serve audited copies from `public/vendor/` and update the script references and Content Security Policy.
- SQLite data is stored in `data/markmuse.sqlite`, created automatically on first run.
- Authentication and per-user document ownership are not implemented. Do not expose this development server publicly without adding authentication, authorization, CSRF/origin protections appropriate to your deployment, backups and production monitoring.
- Pino logs request metadata (method, path, status, duration and request ID) and avoids logging document bodies.
