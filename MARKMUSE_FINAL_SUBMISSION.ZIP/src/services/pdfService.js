const PDFDocument = require("pdfkit");
const { marked } = require("marked");

function compilePdf(title, markdown, response) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const pdf = new PDFDocument({ size: "A4", margins: { top: 56, bottom: 56, left: 54, right: 54 }, bufferPages: true });
    const fail = error => {
      if (!settled) { settled = true; reject(error); }
    };
    pdf.on("error", fail);
    response.setHeader("Content-Type", "application/pdf");
    response.setHeader("Content-Disposition", `attachment; filename="${safeFilename(title)}.pdf"`);
    response.setHeader("Cache-Control", "no-store");
    pdf.pipe(response);

    try {
      pdf.font("Helvetica-Bold").fontSize(22).fillColor("#30275f").text(title, { paragraphGap: 12 });
      pdf.moveDown(0.5);
      pdf.strokeColor("#ddd8f4").moveTo(54, pdf.y).lineTo(541, pdf.y).stroke();
      pdf.moveDown();
      const tokens = marked.lexer(markdown);
      renderTokens(pdf, tokens);
      const range = pdf.bufferedPageRange();
      for (let i = range.start; i < range.start + range.count; i++) {
        pdf.switchToPage(i);
        pdf.font("Helvetica").fontSize(8).fillColor("#777")
          .text(`MarkMuse · Page ${i + 1}`, 54, 780, { width: 487, align: "right", lineBreak: false });
      }
      pdf.end();
      response.on("finish", () => { settled = true; resolve(); });
    } catch (error) {
      fail(error);
      if (!response.headersSent) response.status(500);
      response.end();
    }
  });
}

function renderTokens(pdf, tokens) {
  for (const token of tokens) {
    if (token.type === "heading") {
      const size = [25, 19, 15, 13, 12, 11][token.depth - 1] || 11;
      pdf.moveDown(0.55).font("Helvetica-Bold").fontSize(size).fillColor("#292344")
        .text(plain(token.text), { paragraphGap: 5 });
    } else if (token.type === "paragraph") {
      pdf.font("Helvetica").fontSize(10.5).fillColor("#30303a")
        .text(plain(token.text), { lineGap: 3, paragraphGap: 8 });
    } else if (token.type === "list") {
      token.items.forEach(item => {
        pdf.font("Helvetica").fontSize(10).fillColor("#30303a")
          .text(`${token.ordered ? "•" : "–"}  ${plain(item.text)}`, { indent: 12, paragraphGap: 4 });
      });
      pdf.moveDown(0.35);
    } else if (token.type === "code") {
      pdf.font("Courier").fontSize(8.5).fillColor("#292344")
        .text(token.text.slice(0, 12000), { indent: 10, paragraphGap: 8 });
    } else if (token.type === "blockquote") {
      pdf.font("Helvetica-Oblique").fontSize(10).fillColor("#686078")
        .text(plain(token.text), { indent: 18, paragraphGap: 8 });
    } else if (token.type === "hr") {
      pdf.moveDown().strokeColor("#ddd8f4").moveTo(54, pdf.y).lineTo(541, pdf.y).stroke().moveDown();
    } else if (token.type === "table") {
      const rows = [token.header, ...token.rows];
      rows.forEach((row, index) => {
        const line = row.map(cell => plain(cell.text)).join("   |   ");
        pdf.font(index === 0 ? "Helvetica-Bold" : "Helvetica").fontSize(8.5)
          .text(line.slice(0, 1800), { paragraphGap: 3 });
      });
      pdf.moveDown(0.5);
    }
    if (pdf.y > 720) pdf.addPage();
  }
}

function plain(value) {
  return String(value || "")
    .replace(/!\[([^\]]*)\]\([^)]+\)/g, "$1")
    .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
    .replace(/[`*_~]/g, "")
    .replace(/<[^>]*>/g, "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">");
}

function safeFilename(value) {
  return String(value).replace(/[\\/:*?"<>|]+/g, "").trim().replace(/\s+/g, "-").slice(0, 70) || "document";
}

module.exports = { compilePdf, plain };
