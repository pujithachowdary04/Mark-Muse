const { randomUUID } = require("node:crypto");
const db = require("../db");

const listStmt = db.prepare(
  "SELECT id, title, content, created_at AS createdAt, updated_at AS updatedAt FROM documents ORDER BY updated_at DESC"
);
const getStmt = db.prepare(
  "SELECT id, title, content, created_at AS createdAt, updated_at AS updatedAt FROM documents WHERE id = ?"
);

function list() { return listStmt.all(); }
function get(id) { return getStmt.get(id) || null; }

function create({ title, content }) {
  const id = randomUUID();
  const now = new Date().toISOString();
  const tx = db.transaction(() => {
    db.prepare("INSERT INTO documents (id,title,content,created_at,updated_at) VALUES (?,?,?,?,?)")
      .run(id, title, content, now, now);
    db.prepare("INSERT INTO document_versions (document_id,title,content,created_at) VALUES (?,?,?,?)")
      .run(id, title, content, now);
  });
  tx();
  return get(id);
}

function update(id, { title, content }) {
  const existing = get(id);
  if (!existing) return null;
  const now = new Date().toISOString();
  const tx = db.transaction(() => {
    db.prepare("UPDATE documents SET title=?, content=?, updated_at=? WHERE id=?")
      .run(title, content, now, id);
    db.prepare("INSERT INTO document_versions (document_id,title,content,created_at) VALUES (?,?,?,?)")
      .run(id, title, content, now);
  });
  tx();
  return get(id);
}

function remove(id) {
  return db.prepare("DELETE FROM documents WHERE id = ?").run(id).changes > 0;
}

function versions(id) {
  if (!get(id)) return null;
  return db.prepare(
    "SELECT id, title, content, created_at AS createdAt FROM document_versions WHERE document_id=? ORDER BY created_at DESC"
  ).all(id);
}

module.exports = { list, get, create, update, remove, versions };
