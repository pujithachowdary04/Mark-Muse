const express = require("express");
const path = require("node:path");
const { randomUUID } = require("node:crypto");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const documents = require("./routes/documents");
const logger = require("./logger");

function createApp() {
  const app = express();
  app.disable("x-powered-by");
  app.use(helmet({
    crossOriginResourcePolicy: { policy: "same-origin" },
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "https://cdn.jsdelivr.net"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
        imgSrc: ["'self'", "data:", "blob:"],
        connectSrc: ["'self'"],
        objectSrc: ["'none'"],
        baseUri: ["'self'"],
        frameAncestors: ["'none'"]
      }
    }
  }));
  app.use((req, res, next) => {
    const startedAt = process.hrtime.bigint();
    req.requestId = randomUUID();
    res.setHeader("X-Request-ID", req.requestId);
    res.on("finish", () => {
      const durationMs = Number(process.hrtime.bigint() - startedAt) / 1e6;
      logger.info({
        requestId: req.requestId,
        method: req.method,
        path: req.path,
        statusCode: res.statusCode,
        durationMs: Number(durationMs.toFixed(2))
      }, "HTTP request completed");
    });
    next();
  });
  app.use(express.json({ limit: "600kb" }));
  app.use("/api/", rateLimit({ windowMs: 60 * 1000, limit: 120, standardHeaders: "draft-7", legacyHeaders: false }));
  app.get("/api/health", (_req, res) => res.json({ status: "ok", service: "MarkMuse API" }));
  app.use("/api/documents", documents);
  app.use(express.static(path.join(__dirname, "..", "public")));
  app.use((err, req, res, _next) => {
    logger.error({ err, requestId: req.requestId }, "Unhandled application error");
    if (res.headersSent) return;
    res.status(err.status || 500).json({
      error: err.status && err.status < 500 ? "Request could not be processed" : "Internal server error",
      requestId: req.requestId
    });
  });
  return app;
}

module.exports = { createApp };
