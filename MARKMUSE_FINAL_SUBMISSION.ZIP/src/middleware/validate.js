const { z } = require("zod");

const documentSchema = z.object({
  title: z.string().trim().min(1).max(100),
  content: z.string().max(500000)
}).strict();

function validateDocument(req, res, next) {
  const result = documentSchema.safeParse(req.body);
  if (!result.success) {
    return res.status(400).json({
      error: "Invalid document data",
      details: result.error.issues.map(issue => ({
        field: issue.path.join("."),
        message: issue.message
      }))
    });
  }
  req.validatedDocument = result.data;
  next();
}

module.exports = { validateDocument, documentSchema };
