const express = require("express");
const service = require("../services/documentService");
const { validateDocument } = require("../middleware/validate");
const { compilePdf } = require("../services/pdfService");

const router = express.Router();

router.get("/", (_req, res) => res.json({ documents: service.list() }));

router.post("/", validateDocument, (req, res) => {
  const document = service.create(req.validatedDocument);
  res.status(201).json({ document });
});

router.get("/:id", (req, res) => {
  const document = service.get(req.params.id);
  if (!document) return res.status(404).json({ error: "Document not found" });
  res.json({ document });
});

router.put("/:id", validateDocument, (req, res) => {
  const document = service.update(req.params.id, req.validatedDocument);
  if (!document) return res.status(404).json({ error: "Document not found" });
  res.json({ document });
});

router.delete("/:id", (req, res) => {
  if (!service.remove(req.params.id)) return res.status(404).json({ error: "Document not found" });
  res.status(204).end();
});

router.get("/:id/versions", (req, res) => {
  const versions = service.versions(req.params.id);
  if (!versions) return res.status(404).json({ error: "Document not found" });
  res.json({ versions });
});

// Required PDF compilation endpoint: PDF is generated on the server, not by window.print().
router.post("/compile/pdf", async (req, res, next) => {
  const { documentSchema } = require("../middleware/validate");
  const parsed = documentSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid document data" });
  try {
    await compilePdf(parsed.data.title, parsed.data.content, res);
  } catch (error) {
    next(error);
  }
});

module.exports = router;
